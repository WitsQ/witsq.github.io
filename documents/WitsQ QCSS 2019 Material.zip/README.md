# WitsQ Quantum Computing Summer School 2019

The documents in this archive are only some lectures, labs, and references from the first Quantum Computing Summer School at Wits. Contributors to the content include members of WitsQ, IBM, and UKZN.

## Other references

1. [WitsQ](https://www.wits.ac.za/quantum-computing/)
2. [Qiskit Community Textbook](https://community.qiskit.org/textbook/)
3. [IBM Quantum Experience](https://quantum-computing.ibm.com/)
4. [Quantum Algorithm Zoo](https://quantumalgorithmzoo.org/)
5. [Qiskit Slack](https://qiskit.slack.com/)
6. [WitsQ Github](https://github.com/witsq)